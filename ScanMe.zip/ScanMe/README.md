# COMP 380 Project
## About
Utilizes QR Codes to create and store personalized item information for convenient organization and later retrieval (e.g. tracking the contents of different boxes while packing and moving)

## Team Members:
1. Gabriella de Asis
2. Yu Si
3. Alexis Siguenza
4. Andy Takemoto
